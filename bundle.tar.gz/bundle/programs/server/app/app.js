var require = meteorInstall({"mup.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////
//                                                                        //
// mup.js                                                                 //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
                                                                          //
module.exports = {                                                        // 1
  servers: {                                                              // 2
    one: {                                                                // 3
      // TODO: set host address, username, and authentication method      // 4
      host: '138.197.102.156',                                            // 5
      username: 'root',                                                   // 6
      // pem: './path/to/pem'                                             // 7
      // password: 'server-password'                                      // 8
      // or neither for authenticate from ssh-agent                       // 9
      opts: {                                                             // 10
        port: 22                                                          // 11
      }                                                                   // 10
    }                                                                     // 3
  },                                                                      // 2
  meteor: {                                                               // 16
    // TODO: change app name and path                                     // 17
    name: 'AppTadTokenMeteor',                                            // 18
    path: '../AppTadTokenMeteor',                                         // 19
    servers: {                                                            // 21
      one: {}                                                             // 22
    },                                                                    // 21
    buildOptions: {                                                       // 25
      serverOnly: true                                                    // 26
    },                                                                    // 25
    env: {                                                                // 29
      // TODO: Change to your app's url                                   // 30
      // If you are using ssl, it needs to start with https://            // 31
      ROOT_URL: 'http://cloudbclabs-token.com',                           // 32
      // MONGO_URL: 'mongodb://localhost/meteor',                         // 33
      "PORT": 443                                                         // 34
    },                                                                    // 29
    docker: {                                                             // 37
      // change to 'kadirahq/meteord' if your app is not using Meteor 1.4
      image: 'abernix/meteord:base'                                       // 39
    },                                                                    // 37
    // This is the maximum time in seconds it will wait                   // 43
    // for your app to start                                              // 44
    // Add 30 seconds if the server has 512mb of ram                      // 45
    // And 30 more if you have binary npm dependencies.                   // 46
    deployCheckWaitTime: 600,                                             // 47
    // Show progress bar while uploading bundle to server                 // 49
    // You might need to disable it on CI servers                         // 50
    enableUploadProgressBar: false                                        // 51
  },                                                                      // 16
  mongo: {                                                                // 54
    port: 27017,                                                          // 55
    version: '3.4.1',                                                     // 56
    servers: {                                                            // 57
      one: {}                                                             // 58
    }                                                                     // 57
  }                                                                       // 54
};                                                                        // 1
////////////////////////////////////////////////////////////////////////////

},"server":{"main.js":["meteor/meteor",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////
//                                                                        //
// server/main.js                                                         //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
                                                                          //
var Meteor = void 0;                                                      // 1
module.import('meteor/meteor', {                                          // 1
  "Meteor": function (v) {                                                // 1
    Meteor = v;                                                           // 1
  }                                                                       // 1
}, 0);                                                                    // 1
Meteor.startup(function () {// code to run on server at startup           // 3
});                                                                       // 5
////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json"]});
require("./mup.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
